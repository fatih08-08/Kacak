import re
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
meta = '<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-1026492731881827~5849941019"/>'
if 'APPLICATION_ID' not in s:
    s = s.replace('</application>', '    ' + meta + '\n    </application>', 1)
if 'screenOrientation' not in s:
    s = s.replace('<activity', '<activity android:screenOrientation="sensorLandscape"', 1)
open(p, 'w', encoding='utf-8').write(s)
print(s)
